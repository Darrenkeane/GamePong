using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class WinLose : MonoBehaviour
{
    [SerializeField] private GameObject content;

    [SerializeField] private int targetWin = 5;
    
    [SerializeField]
    private Racket playerLeft, playerRight;

    [SerializeField] private TextMeshProUGUI textWin;

    private void Start()
    {
        content.SetActive(false);
    }

    private void Update()
    {
        if (playerLeft.Score >= targetWin && playerRight.Score <= targetWin)
        {
            content.SetActive(true);
            textWin.text = "PEMAIN KIRI MENANG.";
            Time.timeScale = 0;
        }
        else if (playerLeft.Score < targetWin && playerRight.Score >= targetWin)
        {
            content.SetActive(true);
            textWin.text = "PEMAIN KANAN MENANG.";
            Time.timeScale = 0;
        }
    }
}

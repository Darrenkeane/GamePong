﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Tag
{
    leftWall,
    rightWall,
    leftRacket,
    rightRacket
}
public class TagMenager : MonoBehaviour
{
    public Tag wallTag;
}
